﻿using DesafioFinalDio.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace DesafioFinalDio.Context
{
    public class VendaContext : DbContext
    {
        public VendaContext(DbContextOptions<VendaContext> options) : base(options)
        {

        }

        public DbSet<Venda> Vendas { get; set; }

    }
}