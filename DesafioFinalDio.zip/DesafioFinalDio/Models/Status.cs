﻿namespace DesafioFinalDio.Models
{
    public enum Status
    {

        PagamentoAprovado,
        EnviadoParaTransportadora,
        Entregue,
        Cancelada,
        AguardandoPagamento

    }
}
