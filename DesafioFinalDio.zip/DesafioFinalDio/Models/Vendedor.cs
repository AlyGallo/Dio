﻿namespace DesafioFinalDio.Models
{
    public class Vendedor
    {
        public int VendedorId { get; set; }
        public string NomeVendedor { get; set; }
        public int Cpf { get; set; }
        public string Email { get; set; }
        public int Telefone { get; set; }

    }
}
