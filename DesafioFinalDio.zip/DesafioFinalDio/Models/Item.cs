﻿namespace DesafioFinalDio.Models
{
    public class Item
    {
        public int ItemId { get; set; }
        public string NomeItem { get; set; }
    }
}
