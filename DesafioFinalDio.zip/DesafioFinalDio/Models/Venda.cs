﻿namespace DesafioFinalDio.Models
{
    public class Venda
    {
        public int VendaId { get; set; }
        public Vendedor Vendedor { get; set; }
        public DateTime Data { get; set; }
        public Item Item { get; set; }
        public Status Status { get; set; }

    }
}
