﻿using DesafioFinalDio.Context;
using DesafioFinalDio.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Status = DesafioFinalDio.Models.Status;

namespace DesafioFinalDio.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VendaController : ControllerBase
    {
        
            private readonly VendaContext _context;

            public VendaController(VendaContext context)
            {
                _context = context;
            }

        [HttpGet("{id}")]
        public IActionResult ObterPorId(int id)
        {
            var venda = _context.Vendas.Find(id);

            if (venda == null)
                return NotFound();

            return Ok(venda); 
        }

        [HttpGet("ObterTodos")]
        public IActionResult ObterTodos()
        {
            var venda = _context.Vendas;

            return Ok(venda); 
        }

        [HttpPost]
        public IActionResult RegistrarVenda(Venda venda)
        {
            if (venda.Data == DateTime.MinValue)
                return BadRequest(new { Erro = "A data da tarefa não pode ser vazia" });

            _context.Add(venda);
            _context.SaveChanges();
            return CreatedAtAction(nameof(ObterPorId), new { id = venda.VendaId }, venda); 
        }

        [HttpPut("{id}")]
        public IActionResult Atualizar(int id, Venda venda)
        {
            var vendaBanco = _context.Vendas.Find(id);

            if (vendaBanco == null)
                return NotFound();

            if (venda.Data == DateTime.MinValue)
                return BadRequest(new { Erro = "A data da venda não pode ser vazia" });

            if (vendaBanco.Status == Status.AguardandoPagamento)
                vendaBanco.Status = Status.PagamentoAprovado;
            vendaBanco.Status = Status.Cancelada;


            if (vendaBanco.Status ==  Status.PagamentoAprovado)
                vendaBanco.Status = Status.EnviadoParaTransportadora;
            vendaBanco.Status = Status.Cancelada;

            if (vendaBanco.Status == Status.PagamentoAprovado)
                vendaBanco.Status = Status.Entregue;

            //if (vendaBanco.Status == Status.AguardandoPagamento)
            //    if (venda.Status == Status.PagamentoAprovado || vendaBanco.Status == Status.Cancelada)
            //    {
            //        vendaBanco.Status = venda.Status;
            //    }
            //    else
            //    {
            //        return BadRequest(new { Erro = "Status não permitido" });
            //    }

            //if (vendaBanco.Status == Status.PagamentoAprovado)
            //    if (venda.Status == Status.EnviadoParaTransportadora || vendaBanco.Status == Status.Cancelada)
            //    {
            //        vendaBanco.Status = venda.Status;
            //    }
            //    else
            //    {
            //        return BadRequest(new { Erro = "Status não permitido" });
            //    }

            //if (vendaBanco.Status == Status.EnviadoParaTransportadora)
            //{
            //    vendaBanco.Status = venda.Status;
            //}
            //else
            //{
            //    return BadRequest(new { Erro = "Status não permitido" });
            //}


            _context.Update(vendaBanco);
            _context.SaveChanges();
            return Ok(vendaBanco);   //funcionando
        }
    }
}
